simple interface on simpel website to have some interaction with ESP32
index.html will be read from SDcard on startup
voting results for audio-fragments are stored on SDcard

future expansion: ESP32 sends error messages to website
