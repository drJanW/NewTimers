#include "SDPolicy.h"
#include "SDVoting.h"       // weighted voting/selection helpers
#include "Globals.h"        // for PF/PL macros if needed
#include "PlayFragment.h"   // exposes getRandomFragment helper

namespace SDPolicy {

bool getRandomFragment(AudioFragment& outFrag) {
    // Delegate to fragment helper that already applies weighting rules
    return ::getRandomFragment(outFrag);
}

bool deleteFile(uint8_t dirIndex, uint8_t fileIndex) {
    // Policy: only delete if audio is idle
    if (!isAudioBusy() && !isSentencePlaying()) {
        SDVoting::deleteIndexedFile(dirIndex, fileIndex);
        return true;
    }
    // Otherwise reject (ConductManager can retry later)
    PF("[SDPolicy] Reject delete: audio busy\n");
    return false;
}

void showStatus() {
    PF("[SDPolicy] SD ready=%d busy=%d\n", isSDReady(), isSDBusy());
    // Could add more diagnostics here (e.g. number of indexed files)
}

}