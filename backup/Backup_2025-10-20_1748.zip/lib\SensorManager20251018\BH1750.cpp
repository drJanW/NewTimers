#include "BH1750.h"
// All inline in header for minimal footprint.
