// =============================================
// fetchManager.h – TimerManager-driven version
// =============================================

#pragma once
#include <Arduino.h>

bool initFetchManager();
void updateFetchManager();      // legacy poll hook (currently unused)

