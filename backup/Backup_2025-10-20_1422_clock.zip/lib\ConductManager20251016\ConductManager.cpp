#include "ConductManager.h"
#include "AudioPolicy.h"
#include "LightPolicy.h"
#include "SDPolicy.h"
#include "PRTClock.h"
#include "TimerManager.h"
#include "Globals.h"

namespace {

TimerManager &timers() {
    return TimerManager::instance();
}

PRTClock &clockSvc() {
    return PRTClock::instance();
}

String twoDigits(uint8_t v) {
    if (v < 10) {
        String result("0");
        result += String(v);
        return result;
    }
    return String(v);
}

const char *weekdayName(uint8_t dow) {
    static const char *names[] = {
        "zondag", "maandag", "dinsdag",
        "woensdag", "donderdag", "vrijdag", "zaterdag"};
    return (dow < 7) ? names[dow] : "";
}

const char *monthName(uint8_t month) {
    static const char *names[] = {
        "januari", "februari", "maart", "april",
        "mei", "juni", "juli", "augustus",
        "september", "oktober", "november", "december"};
    return (month >= 1 && month <= 12) ? names[month - 1] : "";
}

String buildTimePhrase() {
    String phrase("Het is ");
    phrase += twoDigits(clockSvc().getHour());
    phrase += ':';
    phrase += twoDigits(clockSvc().getMinute());
    return phrase;
}

String buildNowPhrase() {
    String phrase("Het is nu ");
    phrase += weekdayName(clockSvc().getDoW());
    phrase += ' ';
    phrase += String(clockSvc().getDay());
    phrase += ' ';
    phrase += monthName(clockSvc().getMonth());
    phrase += " om ";
    phrase += twoDigits(clockSvc().getHour());
    phrase += ':';
    phrase += twoDigits(clockSvc().getMinute());
    return phrase;
}

} // namespace

bool ConductManager::christmasMode = false;
bool ConductManager::quietHours = false;

void ConductManager::begin() {
    // Schedule recurring tasks
    bool sayTimeScheduled = timers().create(3600000, 0, [](){ intentSayTime(); });      // hourly
    bool fragmentScheduled = timers().create(600000, 0, [](){ intentPlayFragment(); });  // every 10 min
    PF("[Conduct] begin(): sayTime=%d fragment=%d\n", sayTimeScheduled, fragmentScheduled);
}

void ConductManager::update() {
    // Called in loop()
    applyContextOverrides();
}

void ConductManager::intentPlayFragment() {
    AudioFragment frag;
    if (!SDPolicy::getRandomFragment(frag)) {
        PF("[Conduct] intentPlayFragment: no fragment available\n");
        return;
    }
    if (!AudioPolicy::canPlayFragment()) {
        PF("[Conduct] intentPlayFragment: blocked by policy\n");
        return;
    }

    PF("[Conduct] intentPlayFragment: dir=%u file=%u\n", frag.dirIndex, frag.fileIndex);
    AudioManager::instance().startFragment(frag);
}

void ConductManager::intentSayTime() {
    String phrase = buildTimePhrase();
    if (!AudioPolicy::canPlaySentence()) {
        PF("[Conduct] intentSayTime blocked by policy\n");
        return;
    }

    PF("[Conduct] intentSayTime: %s\n", phrase.c_str());
    AudioManager::instance().startTTS(phrase);
}

void ConductManager::intentSayNow() {
    String phrase = buildNowPhrase();
    if (christmasMode) phrase = "Vrolijk Kerstfeest! " + phrase;
    if (!AudioPolicy::canPlaySentence()) {
        PF("[Conduct] intentSayNow blocked by policy\n");
        return;
    }

    PF("[Conduct] intentSayNow: %s\n", phrase.c_str());
    AudioManager::instance().startTTS(phrase);
}

void ConductManager::intentSetBrightness(float value) {
    float adjusted = LightPolicy::applyBrightnessRules(value, quietHours);
    LightManager::instance().setBrightness(adjusted);
}

void ConductManager::intentSetAudioLevel(float value) {
    float adjusted = AudioPolicy::applyVolumeRules(value, quietHours);
    AudioManager::instance().setWebLevel(adjusted);
}

void ConductManager::intentArmOTA(uint32_t window_s) {
    PF("[Conduct] intentArmOTA: window=%us\n", (unsigned)window_s);
    otaArm(window_s);
    // Optionally: stop audio/light during OTA window
    AudioManager::instance().stop();
    LightManager::instance().showOtaPattern();
}

void ConductManager::intentConfirmOTA() {
    PF("[Conduct] intentConfirmOTA\n");
    otaConfirmAndReboot();
}

void ConductManager::setChristmasMode(bool enabled) {
    christmasMode = enabled;
}

void ConductManager::setQuietHours(bool enabled) {
    quietHours = enabled;
}

void ConductManager::applyContextOverrides() {
    static bool quietLogged = false;
    if (quietHours) {
        LightManager::instance().capBrightness(50);
        AudioManager::instance().capVolume(0.3f);
        if (!quietLogged) {
            PF("[Conduct] applyContextOverrides: quiet hours active\n");
            quietLogged = true;
        }
    } else if (quietLogged) {
        PF("[Conduct] applyContextOverrides: quiet hours cleared\n");
        quietLogged = false;
    }
}