// SetUp.cpp

//initiates hardware modules
//also: sets up timers for all cyclic process - in main loop() only timers need to be serviced (updated)

#include <Arduino.h>
#include "ContextManager.h"
#include "Globals.h"
#include "SDManager.h"
#include "WiFiManager.h"
#include "fetchManager.h"
#include "SensorManager.h"
#include "WebInterfaceManager.h"
#include "TimerManager.h"
#include "AudioManager.h"
#include "LightManager.h"
#include "PRTClock.h"
#include "PlayFragment.h"
#include "SayTime.h"
#include "FastLED.h"
#include "SetUp.h"

#include <esp32-hal-adc.h>

extern CRGB leds[];
static volatile bool reqRandomFrag = false;

static PRTClock& clockSvc() {
    return PRTClock::instance();
}

#define LOOPCYCLE 10

LightShowParams testShows[] = {
    {CRGB::White, CRGB::Blue, 10, 8, 16.0f, 8, 1.0f, -100.0f, -100.0f, 140.0f, 24, 0.7f, 10.0f, 20.0f, 12, 18},
    {CRGB::Aqua, CRGB::Navy, 12, 8, 18.0f, 12, 2.0f, 220.0f, 0.0f, 180.0f, 32, 1.2f, 0.0f, 0.0f, 18, 10},
    {CRGB::Yellow, CRGB::Black, 14, 8, 24.0f, 6, 3.0f, 0.0f, 190.0f, 160.0f, 20, 1.5f, 0.0f, 0.0f, 20, 16},
    {CRGB::Orange, CRGB::DeepPink, 16, 12, 14.0f, 10, 4.0f, 120.0f, 120.0f, 110.0f, 18, 0.9f, 60.0f, 60.0f, 16, 16},
    {CRGB::Green, CRGB::Blue, 14, 10, 22.0f, 4, 5.0f, 500.0f, 0.0f, 400.0f, 60, 0.4f, 0.0f, 0.0f, 20, 20},
    {CRGB::Purple, CRGB::Gold, 12, 12, 26.0f, 8, 0.11f, 0.0f, -300.0f, 200.0f, 24, 1.0f, 0.0f, 0.0f, 18, 10},
    {CRGB::Pink, CRGB::Red, 18, 14, 20.0f, 8, 0.13f, -200.0f, -200.0f, 220.0f, 32, 1.0f, 0.0f, 0.0f, 14, 18},
    {CRGB::DeepSkyBlue, CRGB::Magenta, 16, 10, 24.0f, 12, 0.05f, 0.0f, 0.0f, 18.0f, 16, 1.0f, 16.0f, 0.0f, 8, 10},
    {CRGB::Lime, CRGB::Maroon, 15, 9, 18.0f, 10, 0.07f, 0.0f, 0.0f, 18.0f, 16, 1.0f, 0.0f, 16.0f, 10, 6},
    {CRGB::White, CRGB::Black, 16, 12, 20.0f, 12, 0.16f, 0.0f, 0.0f, 18.0f, 16, 1.0f, 10.0f, 10.0f, 7, 9},
    {CRGB::Blue, CRGB::Orange, 14, 10, 17.0f, 9, 0.17f, -10.0f, 10.0f, 24.0f, 20, 1.3f, 25.0f, 0.0f, 4, 20},
    {CRGB::Red, CRGB::Yellow, 16, 10, 21.0f, 12, 0.19f, 0.0f, 0.0f, 20.0f, 14, 0.8f, 8.0f, 18.0f, 13, 5},
    {CRGB::Aqua, CRGB::Green, 13, 9, 19.0f, 7, 0.08f, -10.0f, 10.0f, 24.0f, 20, 1.3f, 25.0f, 0.0f, 4, 20},
    {CRGB::Gold, CRGB::Black, 12, 10, 25.0f, 8, 0.10f, 0.0f, 0.0f, 20.0f, 14, 0.8f, 8.0f, 18.0f, 13, 5}};
const int numShows = sizeof(testShows) / sizeof(testShows[0]);

static int showIdx = 0;

void initAll(void)
{
    PL("[Setup] Start Init \n");
    initRandomSeed();
    initSDManager();
    PF("1 - [SD] SDManager init OK.\n");

    PF("2 - [Timer] TimerManager init OK.\n");
    startWiFiConnect();
    PF("3 - [WiFi] WiFi connect gestart (met retries via TimerManager).\n");
    beginWebInterface();
    setWebInterfaceActive(true);
    PF("4 - [Web] WebInterface init OK.\n");
    initLightManager();
    setBaseBrightness(100);
    setWebBrightness(1.0f);
    PF("5 - [Light] LightManager init OK.\n");
    if (initFetchManager()) {
        PF("6 - [Fetch] FetchManager init OK.\n");
    } else {
        PF("6 - [Fetch] FetchManager init FAILED!\n");
    }
    delay(2000);

    AudioManager::instance().begin();
    delay(2000);
    PF("7 - [Audio] AudioManager init OK.\n");
    SensorManager::init(/*adcPin=*/33, /*ivUpdateMs=*/100, /*thrHigh=*/2000, /*thrLow=*/2000, /*adcPollMs=*/200);

    PF("8 - [Sensor] SensorManager init OK.\n");
    ContextManager_start();
    PF("9 - [Context] ContextManager init OK.\n");

    pinMode(LED_PIN, OUTPUT);
    digitalWrite(LED_PIN, LOW);

    int iv_heartBeatLed = 500;
    //timers.create(iv_heartBeatLed, 0, cb_heartBeatLed);
    int iv_updateWebInterface = 50 * 1000;
    //timers.create(iv_updateWebInterface, 0, cb_updateWebInterface); // DUMMY
    int iv_audioService = LOOPCYCLE;
    //timers.create(iv_audioService, 0, cb_audioService);
    int iv_updateFetchManager = LOOPCYCLE;
    //timers.create(iv_updateFetchManager, 0, cb_updateFetchManager);
    int iv_updateLightManager = LOOPCYCLE;
    //timers.create(iv_updateLightManager, 0, cb_updateLightManager);
    //timers.create(SECONDS_TICK, 0, cb_updateClock);
    int iv_showStatus = 10 * 1000;
    //timers.create(iv_showStatus, 0, cb_showStatus);
    int iv_nextLightShow = 60 * 1000;
    //timers.create(iv_nextLightShow, 0, cb_nextLightShow);
    int iv_randomAudioFragment = 150 * 1000;
    //timers.create(iv_randomAudioFragment, 0, cb_randomAudioFragment);
    int iv_sayTime = 500 * 1000;
    //timers.create(iv_sayTime, 0, cb_sayTime);
    int iv_showAvailableTimers = 234000;
    //timers.create(iv_showAvailableTimers, 0, cb_showAvailableTimers);
    int iv_showAvailableTimersOnMinOnly = 5 * 1000;
    //timers.create(iv_showAvailableTimersOnMinOnly, 0, cb_showAvailableTimersOnMinOnly);

    auto &timers = TimerManager::instance();

    if (!timers.create(iv_audioService, 0, cb_audioService)) {
        PF("[Setup] Failed to create audioService timer\n");
    }
    if (!timers.create(iv_updateFetchManager, 0, cb_updateFetchManager)) {
        PF("[Setup] Failed to create fetchManager timer\n");
    }
    if (!timers.create(SECONDS_TICK, 0, cb_updateClock)) {
        PF("[Setup] Failed to create clock timer\n");
    }
    if (!timers.create(iv_showStatus, 0, cb_showStatus)) {
        PF("[Setup] Failed to create status timer\n");
    }
    if (!timers.create(iv_updateLightManager, 0, cb_updateLightManager)) {
        PF("[Setup] Failed to create lightManager timer\n");
    }
    if (!timers.create(iv_showAvailableTimers, 0, cb_showAvailableTimers)) {
        PF("[Setup] Failed to create timers diagnostic timer\n");
    }
    if (!timers.create(iv_showAvailableTimersOnMinOnly, 0, cb_showAvailableTimersOnMinOnly)) {
        PF("[Setup] Failed to create timers diagnostic-min timer\n");
    }
    if (!timers.create(iv_updateWebInterface, 0, cb_updateWebInterface)) {
        PF("[Setup] Failed to create webInterface timer\n");
    }
    if (!timers.create(iv_nextLightShow, 0, cb_nextLightShow)) {
        PF("[Setup] Failed to create nextLightShow timer\n");
    }
    if (!timers.create(iv_randomAudioFragment, 0, cb_randomAudioFragment)) {
        PF("[Setup] Failed to create randomAudioFragment timer\n");
    }
    if (!timers.create(iv_sayTime, 0, cb_sayTime)) {
        PF("[Setup] Failed to create sayTime timer\n");
    }

    PL("[Setup] Init klaar.\n");
}

int get_random_seed() {
    uint32_t v = esp_random() ^ micros();
    for (int i = 0; i < 32; ++i) {
        v ^= (v << (i & 15)) ^ (micros() & 0xFF);
        delayMicroseconds(50 + i * 3);
    }
    return (int)v;
}

void initRandomSeed() {
    uint32_t seed = esp_random() ^ micros();
    randomSeed(seed);
}

// === CALLBACKS ===============================================================
void cb_updateClock()
{
    clockSvc().update();
}

void cb_randomAudioFragment()
{
    reqRandomFrag = true; // geen SD, geen decode, geen loop hier
}

void cb_showStatus() {
    auto &clk = clockSvc();
    PF("[Status] Datum:  20%02d-%02d-%02d  Tijd: %02d:%02d:%02d\n",
       clk.getYear(), clk.getMonth(), clk.getDay(),
       clk.getHour(), clk.getMinute(), clk.getSecond());
    //todo!!  SensorManager::showStatus(true);   // ← toont raw/high/dur/fired flags
}

void cb_sayTime()
{
    auto &clk = clockSvc();
    SayTime(clk.getHour(), clk.getMinute());
}

void cb_showAvailableTimersOnMinOnly()
{
    TimerManager::instance().showAvailableTimers(false);
}

void cb_nextLightShow()
{
    int idx = showIdx % numShows;
    const LightShowParams &params = testShows[idx];

    PlayLightShow(params);
    PF("[LightDemo] CircleShow #%d gestart (%d totaal) \n",
       idx, numShows);

    showIdx++;
}

void cb_showAvailableTimers()
{
    TimerManager::instance().showAvailableTimers(true);
}

void cb_heartBeatLed() {
    static bool on = false;
    on = !on;
    digitalWrite(LED_PIN, on ? HIGH : LOW);
}

void cb_updateWebInterface()
{
    updateWebInterface();
}


void cb_updateFetchManager()
{
    updateFetchManager();
}

void cb_updateLightManager()
{
    updateLightManager();
}

void cb_audioService()
{
    AudioManager::instance().update(); // decoder laten lopen

    if (reqRandomFrag && !isAudioBusy())
    {
        reqRandomFrag = false;

        AudioFragment frag;
        if (!getRandomFragment(frag))
        {
            PF("[SDManager] Geen geldig random fragment gevonden!\n");
            return;
        }

        const char *path = getMP3Path(frag.dirIndex, frag.fileIndex);
        PF("[SDManager] Gewogen random file uit /%03u/: %03u.mp3  --> %s\n",
           frag.dirIndex, frag.fileIndex, path);

        setAudioLevelRaw(8192); // veilige startintensiteit
                                //   setAudioBusy(true);                 // voorkomt “0” vóór eerste samples

        PlayAudioFragment::start(frag.dirIndex, frag.fileIndex,
                                 frag.startMs, frag.durationMs, frag.fadeMs);
    }
}
