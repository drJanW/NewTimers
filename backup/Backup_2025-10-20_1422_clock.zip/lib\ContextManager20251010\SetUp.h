// SetUp.h
#pragma once
#include <Arduino.h>
//forwarding callbacks - readuce main-loop in to Handling Timers
void cb_updateClock();
void cb_randomAudioFragment();
void cb_showStatus();
void cb_sayTime();
void cb_showAvailableTimers();
void cb_showAvailableTimersOnMinOnly();
void cb_nextLightShow();
void cb_heartBeatLed();
void cb_updateWebInterface();
void cb_audioService();
void cb_updateLightManager();
void cb_updateFetchManager();

void initAll(void);