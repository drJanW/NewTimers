// WebInterfaceManager.h
// (Updated on 2025-05-15 09:45) – Jan

#ifndef WEB_INTERFACE_MANAGER_H
#define WEB_INTERFACE_MANAGER_H

void beginWebInterface();
void updateWebInterface();

#endif
