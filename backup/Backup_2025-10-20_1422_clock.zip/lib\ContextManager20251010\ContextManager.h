#pragma once
#include <Arduino.h>

namespace ContextManager {
  enum class WebCmd : uint8_t { None = 0, NextTrack, DeleteFile };
}

// Webthread → post opdracht
void ContextManager_post(ContextManager::WebCmd cmd, uint8_t dir = 0, uint8_t file = 0);

// Start periodieke tick via TimerManager (NIET in loop() aanroepen)
void ContextManager_start();
