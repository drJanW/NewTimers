#include "LightManager.h"
#include <FastLED.h>
#include "TimerManager.h"
#include <math.h>

// === LED buffer ===
CRGB leds[NUM_LEDS];

// === State & Animatie voor CircleShow ===
static LightShowParams showParams;
static CRGB palette[PALETTE_SIZE];

static uint8_t xPhase = 0, yPhase = 0;
static uint8_t xCycleSec = 10, yCycleSec = 10;

static uint8_t colorPhase = 0;
static uint8_t brightPhase = 0;

// === Render-cadans (50 ms) ===
static volatile bool showDue = false;
static void showTick() { showDue = true; }

// === Tick-functies ===
static void colorCycleTick() { colorPhase++; }
static void brightCycleTick() { brightPhase++; }
static void xPhaseTick() { xPhase++; }
static void yPhaseTick() { yPhase++; }

// === Timers helpers ===
static void startColorCycleTimer(uint8_t sec) {
  timers.cancel(colorCycleTick);
  uint32_t interval = (sec * 1000UL) / 255UL;
  if (interval == 0) interval = 1;
  if (!timers.create(interval, 0, colorCycleTick)) {
    PF("[LightManager] Failed to start color cycle timer\n");
  }
}

static void startBrightCycleTimer(uint8_t sec) {
  timers.cancel(brightCycleTick);
  uint32_t interval = (sec * 1000UL) / 255UL;
  if (interval == 0) interval = 1;
  if (!timers.create(interval, 0, brightCycleTick)) {
    PF("[LightManager] Failed to start brightness cycle timer\n");
  }
}

static void startXPhaseTimer(uint8_t sec) {
  timers.cancel(xPhaseTick);
  uint32_t interval = (sec * 1000UL) / 255UL;
  if (interval == 0) interval = 1;
  if (!timers.create(interval, 0, xPhaseTick)) {
    PF("[LightManager] Failed to start X phase timer\n");
  }
}

static void startYPhaseTimer(uint8_t sec) {
  timers.cancel(yPhaseTick);
  uint32_t interval = (sec * 1000UL) / 255UL;
  if (interval == 0) interval = 1;
  if (!timers.create(interval, 0, yPhaseTick)) {
    PF("[LightManager] Failed to start Y phase timer\n");
  }
}

// === Getters (optioneel extern gebruikt) ===
uint8_t getColorPhase() { return colorPhase; }
uint8_t getBrightPhase() { return brightPhase; }

// === INIT/SETUP ===
void initLightManager() {
  FastLED.addLeds<LED_TYPE, PIN_RGB, LED_RGB_ORDER>(leds, NUM_LEDS);
  FastLED.setMaxPowerInVoltsAndMilliamps(MAX_VOLTS, MAX_MILLIAMPS);
  FastLED.setBrightness(MAX_BRIGHTNESS);

  if (!loadLEDMapFromSD("/ledmap.bin")) {
    PL("[FATAL] LEDMap laden mislukt – systeem gestopt.");
    while (true) delay(1000);
  }

  startColorCycleTimer(10);
  startBrightCycleTimer(10);

  // vaste render-cadans 50 ms
  timers.cancel(showTick);
  if (!timers.create(50, 0, showTick)) {
    PF("[LightManager] Failed to start show timer\n");
  }
}

// === Dispatcher/Update ===
void updateLightManager() {
  // Render en show alleen op 50 ms tick
  if (!showDue) return;
  showDue = false;

  updateDynamicBrightness();

  // Phases lezen
  uint8_t cPh = getColorPhase();
  uint8_t bPh = getBrightPhase();

  // Dynamische radius
  float baseRadius = showParams.radius;
  float radiusOsc  = showParams.radiusOsc;

  float animRadius = baseRadius;
  if (radiusOsc != 0.0f) {
    float osc = bPh / 255.0f;
    if (radiusOsc > 0.0f) {
      animRadius += fabsf(radiusOsc) * sinf(osc * 2.0f * M_PI * showParams.gradientSpeed);
    } else {
      animRadius = -showParams.fadeWidth + fabsf(radiusOsc) * osc;
    }
  }

  // Dynamisch middelpunt
  float centerX = showParams.centerX, centerY = showParams.centerY;
  if (showParams.xAmp != 0.0f) {
    float px = xPhase / 255.0f;
    centerX += showParams.xAmp * sinf(px * 2.0f * M_PI);
  }
  if (showParams.yAmp != 0.0f) {
    float py = yPhase / 255.0f;
    centerY += showParams.yAmp * sinf(py * 2.0f * M_PI);
  }

  // Palette
  generateRGBPalette(showParams.RGB1, showParams.RGB2, palette, PALETTE_SIZE);

  int windowWidth      = showParams.windowWidth > 0 ? showParams.windowWidth : 16;
  uint8_t vensterStart = cPh;
  uint8_t maxBrightness = getBaseBrightness();

  for (int i = 0; i < NUM_LEDS; ++i) {
    LEDPos pos = getLEDPos(i);
    float dx = pos.x - centerX;
    float dy = pos.y - centerY;
    float dist = sqrtf(dx * dx + dy * dy);

    float blend = fabsf(dist - animRadius) / showParams.fadeWidth;
    if (blend > 1.0f) blend = 1.0f;
    if (blend < 0.0f) blend = 0.0f;

    // Quadratische fade
    float fade = 1.0f - blend;
    fade = fade * fade;

    int palIdx = (vensterStart + int(blend * (windowWidth - 1))) % PALETTE_SIZE;
    if (palIdx < 0) palIdx += PALETTE_SIZE;

    CRGB color = palette[palIdx];

    // Minimum brightness + blending
    uint8_t brightness = showParams.minBrightness +
                         uint8_t(fade * (maxBrightness - showParams.minBrightness));
    if (brightness > 0) color.nscale8_video(brightness);
    else                color = CRGB::Black;

    leds[i] = color;
  }

  FastLED.show();  // nu max 20 FPS
}

// === Universele dispatcher ===
void PlayLightShow(const LightShowParams &p) {
  showParams = p;
  xCycleSec = p.xCycleSec > 0 ? p.xCycleSec : 10;
  yCycleSec = p.yCycleSec > 0 ? p.yCycleSec : 10;

  startColorCycleTimer(p.colorCycleSec);
  startBrightCycleTimer(p.brightCycleSec);
  startXPhaseTimer(xCycleSec);
  startYPhaseTimer(yCycleSec);
}

// === Brightness helpers ===
void updateDynamicBrightness() {
  float wb = isWebInterfaceActive() ? getWebBrightness() : 1.0f;

  float factor = wb;
  if (isAudioBusy()) {
    uint16_t raw = getAudioLevelRaw();            // 0..32767
    if (raw) {
      float n = raw / 32768.0f;
      float adj = sqrtf(n) * 1.2f;                // jouw curve
      if (adj > 1.0f) adj = 1.0f;
      factor = adj * wb;
    }
  }

  uint8_t base = getBaseBrightness();             // 0..255
  uint8_t br   = (uint8_t)(factor * base);

  
  if (base && br < BRIGHTNESS_FLOOR && getWebBrightness() > 0.0f) br = BRIGHTNESS_FLOOR;

  FastLED.setBrightness(br);
}

void updateBaseBrightness() {
  float luxFactor = 1.0f - getLux();
  float webFactor = getWebBrightness();
  float total = luxFactor * webFactor;
  if (total < 0.0f) total = 0.0f;
  if (total > 1.0f) total = 1.0f;

  uint8_t base = (uint8_t)(MAX_BRIGHTNESS * total);
  setBaseBrightness(base);
}

// === RGB/HULP ===
void generateRGBPalette(const CRGB &colorA, const CRGB &colorB, CRGB *pal, int n) {
  for (int i = 0; i < n; ++i) {
    float t = (float)i / (float)(n - 1); // n-1 zodat palette[0]==palette[n-1]
    uint8_t blend;
    if (t < 0.5f) {
      blend = (uint8_t)(t * 2.0f * 255.0f); // 0..255
      pal[i] = CRGB(
        lerp8by8(colorA.r, colorB.r, blend),
        lerp8by8(colorA.g, colorB.g, blend),
        lerp8by8(colorA.b, colorB.b, blend));
    } else {
      blend = (uint8_t)((1.0f - (t - 0.5f) * 2.0f) * 255.0f); // 255..0
      pal[i] = CRGB(
        lerp8by8(colorA.r, colorB.r, blend),
        lerp8by8(colorA.g, colorB.g, blend),
        lerp8by8(colorA.b, colorB.b, blend));
    }
  }
}

CRGB blendRGB(const CRGB &c1, const CRGB &c2, uint8_t blend) {
  return CRGB(
    lerp8by8(c1.r, c2.r, blend),
    lerp8by8(c1.g, c2.g, blend),
    lerp8by8(c1.b, c2.b, blend));
}
