#include "LEDMap.h"
#include <SDManager.h>
#include "HWconfig.h"  // voor NUM_LEDS

static LEDPos ledMap[NUM_LEDS];

LEDPos getLEDPos(int index) {
    if (index >= 0 && index < NUM_LEDS) {
        return ledMap[index];
    }
    return {0.0f, 0.0f};
}

bool loadLEDMapFromSD(const char* path) {
    File f = SD.open(path);
    if (!f) return false;

    for (int i = 0; i < NUM_LEDS; i++) {
        float x = 0, y = 0;
        if (f.read((uint8_t*)&x, sizeof(float)) != sizeof(float)) break;
        if (f.read((uint8_t*)&y, sizeof(float)) != sizeof(float)) break;
        ledMap[i] = {x, y};
    }

    f.close();
    return true;
}
