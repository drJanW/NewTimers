#include "ContextManager.h"
#include "Globals.h"
#include "TimerManager.h"
#include "AudioManager.h"
#include "PlayFragment.h"
#include "SDVoting.h"

static volatile ContextManager::WebCmd s_cmd = ContextManager::WebCmd::None;
static volatile uint8_t s_cmdDir = 0, s_cmdFile = 0;
static bool s_nextPending = false;

// 20 ms periodic via TimerManager
static void ctx_tick_cb() {
  // 1) pak één command
  ContextManager::WebCmd cmd = s_cmd;
  if (cmd != ContextManager::WebCmd::None) s_cmd = ContextManager::WebCmd::None;

  // 2) verwerk command
  if (cmd == ContextManager::WebCmd::NextTrack) {
    s_nextPending = true;
  } else if (cmd == ContextManager::WebCmd::DeleteFile) {
    if (!isAudioBusy() && !isSentencePlaying()) {
      SDVoting::deleteIndexedFile(s_cmdDir, s_cmdFile);
    } else {
      s_cmd = ContextManager::WebCmd::DeleteFile; // retry zodra idle
    }
  }

  // 3) NEXT uitvoeren
  if (s_nextPending) {
    if (isAudioBusy() || isSentencePlaying()) {
      AudioManager::instance().stop();
      return; // volgende tick start nieuwe
    }
    AudioFragment frag{};
    if (getRandomFragment(frag)) {
      PlayAudioFragment::start(frag.dirIndex, frag.fileIndex, frag.startMs, frag.durationMs, frag.fadeMs);
    }
    s_nextPending = false;
  }
}

void ContextManager_post(ContextManager::WebCmd cmd, uint8_t dir, uint8_t file) {
  s_cmdDir = dir; s_cmdFile = file; s_cmd = cmd;
}

void ContextManager_start() {
  // Start een 20 ms heartbeat die de context events verwerkt.
  auto &timers = TimerManager::instance();
  timers.cancel(ctx_tick_cb);
  if (!timers.create(20, 0, ctx_tick_cb)) {
    PF("[ContextManager] Failed to start context tick timer\n");
  }
}
