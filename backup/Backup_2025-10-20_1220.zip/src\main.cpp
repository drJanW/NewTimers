#include <Arduino.h>
#include <WiFi.h>

#include "TimerManager.h"
#include "WiFiManager.h"
#include "SDManager.h"
#include "Globals.h"
#include "fetchManager.h"
#include "PRTClock.h"
#include "AudioManager.h"
#include "LightManager.h"

namespace {

void heartbeatTick() {
    static bool ledState = false;
    ledState = !ledState;
    digitalWrite(LED_PIN, ledState ? HIGH : LOW);
}

static bool fetchScheduled = false;
static bool subsystemTimerStarted = false;
static bool clockTimerStarted = false;
static bool audioInitialized = false;
static bool lightInitialized = false;
static bool clockFallbackActive = false;
static bool fallbackStateAnnounced = false;
static uint32_t subsystemLoopStartMs = 0;

constexpr uint32_t NTP_FALLBACK_TIMEOUT_MS = 60000;

void clockTick() {
    Clock.update();
}

void subsystemInitTick() {
    auto &timers = TimerManager::instance();
    uint32_t now = millis();

    if (subsystemLoopStartMs == 0) {
        subsystemLoopStartMs = now;
    }

    if (clockFallbackActive && isTimeFetched()) {
        clockFallbackActive = false;
        fallbackStateAnnounced = false;
        PL("[Main] NTP sync obtained, continuing with real time");
    }

    if (!clockTimerStarted && isTimeFetched()) {
        if (timers.create(SECONDS_TICK, 0, clockTick)) {
            PF("[Main] Clock tick started at %02u:%02u:%02u\n",
                         Clock.getHour(), Clock.getMinute(), Clock.getSecond());
            clockTimerStarted = true;
        } else {
            PL("[Main] Failed to start clock tick timer");
        }
    } else if (!clockTimerStarted && !clockFallbackActive &&
               (now - subsystemLoopStartMs) >= NTP_FALLBACK_TIMEOUT_MS) {
        PL("[Main] Time fetch timeout, starting fallback clock");
        if (timers.create(SECONDS_TICK, 0, clockTick)) {
            clockTimerStarted = true;
            clockFallbackActive = true;
        } else {
            PL("[Main] Failed to start fallback clock timer");
        }
    }

    if (!audioInitialized && isSDReady()) {
        PL("[Main] Audio init");
        AudioManager::instance().begin();
        audioInitialized = true;
    }

    if (!lightInitialized && isSDReady()) {
        PL("[Main] Light init");
        initLightManager();
        setBaseBrightness(100);
        setWebBrightness(1.0f);
        lightInitialized = true;
    }

    if (clockTimerStarted && audioInitialized && lightInitialized) {
        if (clockFallbackActive && !fallbackStateAnnounced) {
            fallbackStateAnnounced = true;
            PL("[Main] Subsystems running (fallback time)");
        }

        if (!isTimeFetched()) {
            return;
        }

        timers.cancel(subsystemInitTick);
        subsystemTimerStarted = false;
        PL("[Main] Subsystems ready");
    }
}

void wifiPollTick() {
    static bool lastWiFiState = false;

    bool wifiUp = isWiFiConnected();
    if (wifiUp && !lastWiFiState) {
        PF("[Main] WiFi connected: %s\n", WiFi.localIP().toString().c_str());
    } else if (!wifiUp && lastWiFiState) {
        PL("[Main] WiFi lost, retrying");
    }

    if (!wifiUp) {
        PL("[Main] WiFi not connected yet");
    }

    lastWiFiState = wifiUp;

    if (wifiUp) {
        auto &timers = TimerManager::instance();

        if (!fetchScheduled) {
            timers.cancel(wifiPollTick);
            PL("[Main] Starting fetch schedulers");
            if (initFetchManager()) {
                fetchScheduled = true;
                PL("[Main] Fetch schedulers started");
            } else {
                PL("[Main] Fetch scheduler start FAILED");
            }
        }

        if (!subsystemTimerStarted) {
            if (timers.create(1000, 0, subsystemInitTick)) {
                subsystemTimerStarted = true;
                PL("[Main] Subsystem monitor timer started");
            } else {
                PL("[Main] Failed to start subsystem timer");
            }
        }
    }
}

} // namespace

void setup() {
    Serial.begin(115200);

    PL("\n[Main] System starting...");

    pinMode(LED_PIN, OUTPUT);
    digitalWrite(LED_PIN, LOW);
    PL("[Main] Status LED ready");

    PL("[Main] SD init start");
    initSDManager();
    PL("[Main] SD init done");

    PL("[Main] WiFi start connect");
    startWiFiConnect();

    PL("[Main] Scheduling fetches (setup)");
    if (initFetchManager()) {
        fetchScheduled = true;
        PL("[Main] Fetch schedulers started (setup)");
    } else {
        PL("[Main] Fetch scheduler start FAILED (setup)");
    }

    auto &timers = TimerManager::instance();
    if (!timers.create(500, 0, heartbeatTick)) {
        PL("[Main] Failed to create heartbeat timer");
    }
    if (!timers.create(1000, 0, wifiPollTick)) {
        PL("[Main] Failed to create WiFi poll timer");
    }

    PL("[Main] Init complete.");
}

void loop() {
    TimerManager::instance().update();
}